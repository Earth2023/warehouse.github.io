import tkinter # 导入tkinter库
windows = tkinter.Tk() # 创建窗体
windows.title("Menu") # 设置标题
windows.geometry("300x150") # 设置大小
Menu = tkinter.Menu(windows) # 创建Menu（菜单）到windows窗体之中
# 等级：顶级
Menu1 = tkinter.Menu(Menu) # 创建Menu（菜单）到Menu顶级菜单之中
# 等级：次级
Menu.add_cascade(label="这是一个菜单", menu=Menu1) # 添加Menu1菜单到Menu顶级菜单中并取名为“这是一个菜单”
Menu1.add_command(label="Hello world!", command=lambda : print("Hello world!")) # 在次级菜单中创建一个子级菜单，名为Hello world!
# 当被点击后调用函数print输出Hello world!
Menu1.add_separator()
windows['menu'] = Menu # 添加Menu进入windows
windows.mainloop() # 进入主事件循环