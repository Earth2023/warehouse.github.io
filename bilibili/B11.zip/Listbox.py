import tkinter # 导入tkinter库
windows = tkinter.Tk() # 创建窗体
windows.title("Listbox") # 设置标题
windows.geometry("300x150") # 设置大小
Listbox1 = tkinter.Listbox(windows, selectmode=tkinter.SINGLE) # 创建Listbox在windows窗体之中，选择方式为单选
Listbox1.pack()
for i in range(20):
    Listbox1.insert('end', str(i))
windows.mainloop() # 进入主事件循环