import tkinter
p = tkinter.Tk()  # 定义窗体，窗体的所有方法使用p来
p.geometry('500x500')   # 定义窗体大小，需要使用字符串，左边是width（宽度）， 右边是height（高度），中间使用小写的X
p.iconbitmap('C:\\Users\\1\\Desktop\\杀毒\\Earth2023_Antivirus.ico')
p.title("Hello Tkinter!(By Earth2023)")   # 设置窗体标题
Hello = tkinter.Button(p, font=("微软硬黑", 20), text="控制台输出", command=lambda : print("Hello world!"))
# button的第一个参数是创建于x窗体中，font定义字体与字的大小，text是按钮的文本内容，而command是按钮被点击后执行的函数（事件）
Hello.pack()   # 正式将Hello按钮添加进窗体中，里面可以设置x坐标和y坐标
p.mainloop()   # 进入窗体主事件循环