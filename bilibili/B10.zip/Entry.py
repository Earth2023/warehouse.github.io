import tkinter
tk = tkinter.Tk()
num1 = tkinter.Entry(tk)
num1.pack()
num2 = tkinter.Button(tk, command=lambda : print(num1.get()), text="00000")
num2.pack()
tk.mainloop()