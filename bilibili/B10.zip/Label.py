import tkinter
import time
TK = tkinter.Tk() # 创建窗体TK
TK.title("Label控件程序") # 设置窗体标题
TK.geometry('500x500') # 设置窗体大小
TK.iconbitmap("H:\\E\\项目\\杀毒\\Earth2023_Antivirus.ico") # 设置窗体标题旁的logo
num1 = tkinter.Label(TK, text="这是我的Label控件程序！\n现在是{0}".format(time.strftime("%Y-%m-%d")), anchor='w', fg="red", font=("微软硬黑", 30)) # 创建一个Label控件赋值给num1
num1.pack() # 添加num1进入窗体
TK.mainloop()