import tkinter
tk = tkinter.Tk() # 创建窗体
num1 = tkinter.Button(tk, text="哦？现在几点了？", command=lambda : print("现在是2023 7 25 21 51（doge）")) # 创建Button按钮控件进入num1，并设计点击后执行事件
num1.pack()
tk.mainloop()